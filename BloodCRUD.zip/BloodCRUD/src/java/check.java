

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class check implements Filter {
    
    
 
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException {
            response.setContentType("text/html");
            
            String b1 = request.getParameter("name");
            String b2 = request.getParameter("city");
            String b3 = request.getParameter("Adnum");
            String b4 = request.getParameter("btype");
            
            if(b1.equals("") || b2.equals("") || b3.equals("") || b4.equals(""))
            {
                PrintWriter out = response.getWriter();
                out.println("Data can't be Empty");
            }
            else
            {
                chain.doFilter(request, response);
            }
            
            
       
    }

   
    
    public void destroy() {        
    }

    
    public void init(FilterConfig filterConfig) {        
        
    }

    
    
}
