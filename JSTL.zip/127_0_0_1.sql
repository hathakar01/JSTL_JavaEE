-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2022 at 08:02 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cs_project`
--
CREATE DATABASE IF NOT EXISTS `cs_project` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cs_project`;

-- --------------------------------------------------------

--
-- Table structure for table `allusers`
--

CREATE TABLE `allusers` (
  `uid` varchar(20) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `upass` varchar(20) NOT NULL,
  `uemail` varchar(30) NOT NULL,
  `umobileno` varchar(10) NOT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `State` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `allusers`
--

INSERT INTO `allusers` (`uid`, `uname`, `upass`, `uemail`, `umobileno`, `Gender`, `dob`, `Address`, `State`, `Country`) VALUES
('abhilasha', 'Abhilasha', 'V@sant0pp', 'demo@gmail.com', '1234567890', NULL, NULL, NULL, NULL, NULL),
('amiruddin1', 'Aamir Samlayawala', 'Aamir@308', 'ami.coolboy2001@gmail.com', '9087654321', 'Male', '2001-08-03', ' Panigate- 390019    ', 'Vadodara', 'Gujarat'),
('chin', 'chintu', 'chintan1101@', 'chin@gmail.com', '9087654321', 'Male', '2001-08-03', 'Panigate Vadodara- 390019', 'Vadodara', 'Gujarat'),
('Husain0501', 'Husain Ali Samlayawala', 'Husain@0501', 'husain1599@gmail.com', '9087654321', 'Male', '2001-08-03', 'Panigate Vadodara- 390019', 'Vadodara', 'Gujarat'),
('Mahi', 'Mahendra Singh Dhoni', 'Mahi@7781', 'mahi7781@gmail.com', '9087654321', 'Male', '2001-08-03', 'Mahalaxmi Park', 'Ranchi', 'UP'),
('Mahir', 'Mahir Saiyed', 'mahir@123', 'mahir@gmail.com', '9087654321', 'Male', '2001-08-03', 'Panigate Vadodara- 390019', 'Vadodara', 'Gujarat'),
('Mufz3093', 'Mufazzal Jariwala', 'Mufz@3093', 'mufz3093@gmail.com', '9712207347', 'Male', '2004-09-30', ' Mogalwada Tai Wada', 'Vadodara', 'Gujarat'),
('SakanMuka', 'Sakina Samlayawala', 'Sakina@3009', 'sakinamuku@gmail.com', '9087654321', 'Male', '2001-08-03', 'Panigate Vadodara- 390019', 'Vadodara', 'Gujarat'),
('VK18', 'Virat Kohli', 'Virat@18', 'virat.kohli@gmail.com', '9087654321', 'Male', '2001-08-03', 'Panigate Vadodara- 390019', 'Vadodara', 'Gujarat');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `C_ID` int(11) NOT NULL,
  `C_PID` varchar(11) DEFAULT NULL,
  `C_PDESC` varchar(100) NOT NULL,
  `C_PQTY` varchar(11) NOT NULL,
  `C_PPRICE` varchar(11) NOT NULL,
  `C_PSELLER` varchar(100) DEFAULT NULL,
  `CAT_ID` varchar(11) DEFAULT NULL,
  `C_PName` varchar(50) DEFAULT NULL,
  `uid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`C_ID`, `C_PID`, `C_PDESC`, `C_PQTY`, `C_PPRICE`, `C_PSELLER`, `CAT_ID`, `C_PName`, `uid`) VALUES
(36, '48', 'Ladies Pink Frock ', '1', '1599', 'Amazon & Co.', '2', 'Frock', 'VK18'),
(46, '44', '8 GB RAM, 1 TB Storage', '1', '100000', 'Flipcart Ltd.', '1', 'Laptop', 'amiruddin1'),
(55, '44', '8 GB RAM, 1 TB Storage', '1', '100000', 'Flipcart Ltd.', '1', 'Laptop', 'Mahi');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `C_ID` int(11) NOT NULL,
  `C_NAME` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`C_ID`, `C_NAME`) VALUES
(1, 'ELECTRONICS'),
(2, 'MEN/WOMEN WEARS'),
(3, 'HOME APPLIANCES'),
(4, 'MOBILE ACCESSORIES'),
(5, 'FOOT WEAR'),
(6, 'CROCKERY'),
(7, 'Hardware'),
(8, 'Others'),
(9, 'Stationery');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ORDER_ID` int(11) NOT NULL,
  `P_ID` varchar(20) DEFAULT NULL,
  `OP_NAME` varchar(50) NOT NULL,
  `OP_DESC` varchar(50) NOT NULL,
  `OP_PRICE` varchar(50) NOT NULL,
  `OP_QTY` varchar(50) NOT NULL,
  `OC_NAME` varchar(50) NOT NULL,
  `OP_SELLER` varchar(50) NOT NULL,
  `O_TIME` datetime NOT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ORDER_ID`, `P_ID`, `OP_NAME`, `OP_DESC`, `OP_PRICE`, `OP_QTY`, `OC_NAME`, `OP_SELLER`, `O_TIME`, `user_id`) VALUES
(10, '44', 'Laptop', '8 GB RAM, 1 TB Storage', '100000', '1', 'ELECTRONICS', 'Flipcart Ltd.', '2022-10-23 12:03:01', 'amiruddin1'),
(11, '53', 'Laxmi Mojdi', 'Ledies Mojdi 10 Number', '499', '1', 'FOOT WEAR', 'Flipcart Ltd.', '2022-10-23 12:10:35', 'amiruddin1'),
(12, '44', 'Laptop', '8 GB RAM, 1 TB Storage', '100000', '1', 'ELECTRONICS', 'Flipcart Ltd.', '2022-10-23 12:13:25', 'VK18'),
(13, '54', 'LG Oven', 'LG Oven High Speed', '34000', '3', 'HOME APPLIANCES', 'Amazon & Co.', '2022-11-10 20:37:38', 'amiruddin1'),
(14, '52', 'Bhagyoday Plate set', '10X Plate', '850', '2', 'CROCKERY', 'Flipcart Ltd.', '2022-11-12 09:25:18', 'amiruddin1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductId` int(11) NOT NULL,
  `Pname` varchar(30) NOT NULL,
  `PDesc` varchar(100) NOT NULL,
  `PQty` int(11) NOT NULL,
  `PPrice` int(11) NOT NULL,
  `PSeller` varchar(100) NOT NULL,
  `CAT_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductId`, `Pname`, `PDesc`, `PQty`, `PPrice`, `PSeller`, `CAT_ID`) VALUES
(44, 'Laptop', '8 GB RAM, 1 TB Storage', 60, 100000, 'Flipcart Ltd.', 1),
(47, 'Men Jeans', 'XL Size', 1, 599, 'Amazon & Co.', 2),
(48, 'Frock', 'Ladies Pink Frock ', 1, 1599, 'Amazon & Co.', 2),
(49, 'LG Fridge', 'Double Door', 1, 25000, 'Amazon & Co.', 3),
(50, 'MI Note 9 Pro Max Cober', 'MI Note 9 Pro Max Phone Cover', 1, 300, 'Amazon & Co.', 4),
(51, 'Bahamas Footwear', 'Gents Slipper', 1, 210, 'Flipcart Ltd.', 5),
(52, 'Bhagyoday Plate set', '10X Plate', 1, 850, 'Flipcart Ltd.', 6),
(53, 'Laxmi Mojdi', 'Ledies Mojdi 10 Number', 1, 499, 'Flipcart Ltd.', 5),
(54, 'LG Oven', 'LG Oven High Speed', 1, 34000, 'Amazon & Co.', 3),
(55, 'Usha Fan', '4 Pankh Wala Fan Jo bijli se chalta hai', 1, 1900, 'Amazon & Co.', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allusers`
--
ALTER TABLE `allusers`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`C_ID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`C_ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ORDER_ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ORDER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- Database: `employeedb`
--
CREATE DATABASE IF NOT EXISTS `employeedb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `employeedb`;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `empid` int(11) NOT NULL,
  `empname` varchar(30) NOT NULL,
  `empdesg` varchar(40) NOT NULL,
  `empsal` int(11) NOT NULL,
  `empjoin` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`empid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `empid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Database: `hostelmanagment`
--
CREATE DATABASE IF NOT EXISTS `hostelmanagment` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hostelmanagment`;

-- --------------------------------------------------------

--
-- Table structure for table `fees_mst`
--

CREATE TABLE `fees_mst` (
  `studentid` int(11) NOT NULL,
  `date` date NOT NULL,
  `subject` varchar(45) NOT NULL,
  `center` varchar(45) NOT NULL,
  `amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login_mst`
--

CREATE TABLE `login_mst` (
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_mst`
--

INSERT INTO `login_mst` (`UserName`, `Password`) VALUES
('abc@gmail.com', '1234567890'),
('admin', 'admin'),
('Dhoni', 'dhoni'),
('Ketan', 'Ketan'),
('VK', 'Virat@18');

-- --------------------------------------------------------

--
-- Table structure for table `newregestration`
--

CREATE TABLE `newregestration` (
  `studentid` int(45) NOT NULL,
  `student name` varchar(50) NOT NULL,
  `Mobileno` varchar(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `pin code` varchar(6) NOT NULL,
  `Student's fathername` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `fmobileno` varchar(10) NOT NULL,
  `cast` varchar(10) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `metritalstatus` varchar(10) NOT NULL,
  `Gender` varchar(34) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newregestration`
--

INSERT INTO `newregestration` (`studentid`, `student name`, `Mobileno`, `email`, `pin code`, `Student's fathername`, `address`, `fmobileno`, `cast`, `dob`, `metritalstatus`, `Gender`) VALUES
(1, 'Ketan', '9087655432', 'ketan.mca@gmail.com', '90876', 'Rajesh Bhai', 'Anand', '9087754321', 'General', '09-09-2001', 'Unmarried', 'Male'),
(3, 'Amir', '9098765900', 'abcd@gmail.com', '90878', 'insaan', 'Vadodara', '890567899', 'General', '08-09-2003', 'Female', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `roomno` int(11) NOT NULL,
  `location` varchar(45) NOT NULL,
  `capacity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomno`, `location`, `capacity`) VALUES
(1, 'firstflore', 6),
(2, 'firstflore', 6),
(3, 'firstflore', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fees_mst`
--
ALTER TABLE `fees_mst`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `login_mst`
--
ALTER TABLE `login_mst`
  ADD PRIMARY KEY (`UserName`);

--
-- Indexes for table `newregestration`
--
ALTER TABLE `newregestration`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`roomno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `newregestration`
--
ALTER TABLE `newregestration`
  MODIFY `studentid` int(45) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Database: `jstldemo`
--
CREATE DATABASE IF NOT EXISTS `jstldemo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `jstldemo`;

-- --------------------------------------------------------

--
-- Table structure for table `tbldemo`
--

CREATE TABLE `tbldemo` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbldemo`
--

INSERT INTO `tbldemo` (`id`, `name`, `age`, `city`) VALUES
(1, 'Amir', 22, 'Vadodara');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbldemo`
--
ALTER TABLE `tbldemo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbldemo`
--
ALTER TABLE `tbldemo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin DEFAULT NULL,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

--
-- Dumping data for table `pma__favorite`
--

INSERT INTO `pma__favorite` (`username`, `tables`) VALUES
('root', '[]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"jstldemo\",\"table\":\"tbldemo\"},{\"db\":\"hostelmanagment\",\"table\":\"room\"},{\"db\":\"hostelmanagment\",\"table\":\"newregestration\"},{\"db\":\"hostelmanagment\",\"table\":\"login_mst\"},{\"db\":\"hostelmanagment\",\"table\":\"fees_mst\"},{\"db\":\"hostelmanagment\",\"table\":\"roomallocation\"},{\"db\":\"hostelmanagment\",\"table\":\"finalconform\"},{\"db\":\"phonebook\",\"table\":\"contacts\"},{\"db\":\"cs_project\",\"table\":\"cart\"},{\"db\":\"cs_project\",\"table\":\"Cart\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'cs_project', 'cart', '{\"sorted_col\":\"`cart`.`C_PDESC` ASC\"}', '2022-10-22 07:42:59');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin DEFAULT NULL,
  `data_sql` longtext COLLATE utf8_bin DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2022-11-22 04:35:04', '{\"Console\\/Mode\":\"collapse\",\"NavigationWidth\":327}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
